class Main {
  public static void main(String[] args) {
   int a=5, b=8, c;
    c= ++a +b -a;
    boolean c;
    a++ ++b *c /d;
    c=a>b*a;
    System.out.println ("result of c is " +c);
  }
}