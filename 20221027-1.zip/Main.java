class Main{
  public static void main{string[]args}{
}
{
    static int arr[] = {20, 250, 65, 80, 9045};
    static int largest()
    {
        int i;
        int max = arr[0];
        for (i = 1; i < arr.length; i++)
            if (arr[i] > max)
                max = arr[i];
         
        return max;
    }
    public static void main(String[] args)
    {
        System.out.println("maximum value is" + largest());
    }

  public class Main {
    public static void main(String[] args) {
    int []arr = new int []{20,10,30,50,40};
    int min = arr [0];
      for (int i = 1; 1 < arr.length ; i++)
        {
         if(arr{i}>min)
           {
          min = arr[i];
        }
               }
          System.out.println("minimum value is" + min);
    }
}