class Main {
  public static void main(String[] args) {
int a=111, b=222, c=444;  
if(a>=b && a>=c)  
System.out.println(a+" is the largest Number");  
else if (b>=a && b>=c)  
System.out.println(b+" is the largest Number");  
else  
System.out.println(c+" is the largest number");  
}  
}  
