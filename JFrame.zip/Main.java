import javax.swing.*;
  class Main{
    public static void main(String[]args){
      JFrame fr= new JFrame("Introducing jframe");
      JButton bt=new JButton ("Click");
      fr.add(bt);
      bt.setBounds(100,100,100,100);
      fr.setSize(500,500);
      fr.setLayout(null);
      fr.setVisible(true);
    }
  }
