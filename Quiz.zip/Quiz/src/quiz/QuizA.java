/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package quiz;

import java.awt.Dimension;
import javax.swing.JOptionPane;

/**
 *
 * @author janicemang
 */
public class QuizA extends javax.swing.JFrame {
    /**
     * Creates new form QuizA
     */
    int question1Answer = -1;       //store which subject selected
    int question2Answer = -1;       //store Level of Difficulty selected
    
    //STORE ALL QUESTIONS AND ANSWERS (OPTION)
    //QUESTION ENGLISH
    String questionE[][] = new String[][] {
        {   "Question 1: Which spelling is correct?", 
            "Question 2: Which is correct for the following sentence?____ went to the playground today.", 
            "Question 3: Click the correct definition for a Verb.", 
            "Question 4: Which word in this sentence is a pronoun? She likes to eat strawberries.", 
            "Question 5: Which word here is a preposition? “House,””In,” or “Run”"
        },
        {   "Question 1: Choose the correct form of pronoun to complete the sentence: Ricky and __ went to the movies.", 
            "Question 2: Choose the correct verb to complete the sentence: Hanbin __ a book when I saw him.", 
            "Question 3: Choose the correct conjunction to complete the sentence: Gyuvin studied hard, ___ he passed the exam.", 
            "Question 4: Choose the correct noun to complete the sentence: Please pass me __________.", 
            "Question 5: Choose the correct verb to complete the sentence: I ___ my keys. Can you help me find them?"
        },
        {   "Question 1: What is the definition of “Onomatopoeia”?", 
            "Question 2: Which word is spelt correctly?", 
            "Question 3: What does the term \"cognitive dissonance\" refer to?", 
            "Question 4: What is the definition of \"hyperbole\"?", 
            "Question 5: How do you spell the adjective form of the word \"persist\"?"
        }
    };
    
    //QUESTION MATH        
    String questionM[][] = new String[][] {
        {   "Question 1: 1+1=", 
            "Question 2: 1-2=", 
            "Question 3: 3x3=", 
            "Question 4: 17+3", 
            "Question 5: 10 ÷ 5"
        },
        {   "Question 1: 3² - 4 × 2 + 5=", 
            "Question 2: Simplify 2(4 + 3) ÷ 5", 
            "Question 3: Solve 2x + 5 = 17", 
            "Question 4: What is the median of the following set of numbers: 4, 7, 9, 12, 15?", 
            "Question 5: What is the value of 2x + 3y when x = 4 and y = 5?"
        },
        {   "Question 1: A car travels at a speed of 60 miles per hour. How far will it travel in 2.5 hours?", 
            "Question 2: A square has a perimeter of 40 cm. What is the area of the square?",
            "Question 3: A train travels a distance of 300 km in 4 hours. What is its average speed in meters per second?", 
            "Question 4: A bookstore gives a 20% discount on all books. If a book originally costs $50, how much will it cost after the discount?",
            "Question 5: A bakery sells cakes for $25 each. If the bakery sells 40 cakes, how much revenue does it generate?"
        }
    };
    
    //ANSWER ENGLISH, DELIMITED BY |, MAX 4 OPTIONS
    String answerE[][] = new String[][] {
        {   "Butterfly|Buttrefly|Butterflie|Butterfligh",
            "Him|Their|Whom|He",
            "A verb is a word that describes or modifies a pronoun or noun.|A verb is a word that describes an action, occurrence, or state of being.",
            "She|Likes|Eat|Strawberries",
            "House|In|Run|None of the above"
        },
        {   "me|I|she|her",
            "reads|is reading|was reading|has read",
            "but|or|and|so",
            "the scissors|an scissors|a scissors|a scissor",
            "find|lost|lose|have lose"
        },
        {   "A figure of speech where contradictory terms are combined for emphasis.|The attribution of human characteristics to inanimate objects or animals.|The use of words that imitate the sounds associated with the objects or actions they refer to.|A comparison between two unlike things using \"like\" or \"as.\"",
            "Occurrence|Ocurence|Occurense|Ocurrence",
            "The process of deriving meaning from language through decoding.|A psychological state characterized by inconsistency between beliefs and actions.|A technique used in persuasive writing to evoke emotional responses.|The study of the sounds of human speech.",
            "A figure of speech in which contradictory terms are combined for emphasis.|The attribution of human characteristics to inanimate objects or animals.|Exaggerated statements or claims not meant to be taken literally.|The study of the sounds of human speech.",
            "Persistanse|Persistance|Persistence|Persistense"
        }
    };
    
    //ANSWER MATH, DELIMITED BY |, MAX 4 OPTIONS
    String answerM[][] = new String[][] {
        {   "2|3|4|5",
            "-1|0|3|2",
            "6|3|9|0",
            "27|20|18|15",
            "2|5|10|-5"
        },
        {   "5|7|9|11",
            "1|2|3|4",
            "6|8|9|10",
            "7|9|11|12",
            "10|11|12|13"
        },
        {   "120 miles|150 miles|170 miles|130 miles",
            "100 cm²|121 cm²|144 cm²|169 cm²",
            "12.5 m/s|20 m/s|30 m/s|40 m/s",
            "$10|$20|$30|$40",
            "$800|$1,000|$1,200|$1,500"
        }
    };

    //RESET ALL VARIABLES LIKE FIRST ENTER THE PROGRAM
    private void resetQuiz(){
        question1Answer = -1;
        question2Answer = -1;
        
        jTextField1.setText("");
        resetAnswer();
        makePanelVisible(1);
    }
    
    //CLEAR ALL PREVIOUS ANSWERS SELECTED
    private void resetAnswer() {
        ButtonGroupQ1.clearSelection();
        buttonGroupQ2.clearSelection();
        buttonGroupQ3.clearSelection();
        buttonGroupQ4.clearSelection();
        buttonGroupQ5.clearSelection();
    }
    
    //MAKE A PANEL VISIBLE FOR EACH STEP
    private void makePanelVisible(int whichPanel) {
        jPanel1.setVisible(false);
        jPanel2.setVisible(false);
        jPanel3.setVisible(false);
        jPanel4.setVisible(false);
                
        switch (whichPanel) {
            case 1 -> {  
                //this.setPreferredSize(new Dimension(350, 25));
                jPanel1.setPreferredSize(new Dimension(1184, 787));
                jPanel1.setVisible(true);
                this.pack();
                this.repaint();
                
            }
            case 2 -> {
                jPanel2.setPreferredSize(new Dimension(1184, 787));
                jPanel2.setVisible(true);
                this.pack();
                this.repaint();
            }
            case 3 -> {
                jPanel3.setPreferredSize(new Dimension(1184, 787));
                jPanel3.setVisible(true);
                this.pack();
                this.repaint();
            }
            case 4 -> {
                jPanel4.setPreferredSize(new Dimension(1184, 787));
                jPanel4.setVisible(true);
                this.pack();
                this.repaint();
            }
        }
    }
    
    //DETERMINE WHICH STEP TO GO
    private void gotoStep( int step) {
        switch (step) {
            case 0 -> {
                resetQuiz();
            }
            case 1 -> {
                makePanelVisible(2);
            }
            case 2 -> {
                makePanelVisible(3);
                
                loadQuestion();
            }
            default -> {
                makePanelVisible(4);
                
                calculateScore();
            }
        }
    }
    
    //CALCULATE TOTAL SCORES
    private void calculateScore() {
        int totalScore = 0;
        
        if (question1Answer == 0) {
            //ENGLISH
            if (question2Answer == 0) { //EASY
                if (jRadioButton1.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton8.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton10.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton13.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton18.isSelected() == true) {
                    totalScore += 1; 
                }
            }
            if (question2Answer == 1) { //MEDIUM
                if (jRadioButton2.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton7.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton11.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton13.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton18.isSelected() == true) {
                    totalScore += 1; 
                }
            }
            if (question2Answer == 2) { //HARD
                if (jRadioButton3.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton5.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton10.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton15.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton19.isSelected() == true) {
                    totalScore += 1; 
                }
            }
        }
        else
        {
            //math
            if (question2Answer == 0) { //EASY
                if (jRadioButton1.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton5.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton11.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton14.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton17.isSelected() == true) {
                    totalScore += 1; 
                }
            }
            if (question2Answer == 1) { //MEDIUM
                if (jRadioButton1.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton7.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton12.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton14.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton20.isSelected() == true) {
                    totalScore += 1; 
                }
            }
            if (question2Answer == 2) { //HARD
                if (jRadioButton2.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton7.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton11.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton16.isSelected() == true) {
                    totalScore += 1; 
                }
                if (jRadioButton19.isSelected() == true) {
                    totalScore += 1; 
                }
            }
        }
        jTextField1.setText(totalScore + " / 5");
    }
    
    //LOAD ALL QUESTIONS BASE ON USER SELECTIONS
    private void loadQuestion() {
        resetAnswer();
        
        if (question1Answer == 0) {
            //ALL ENGLISH
            jLabel4.setText(questionE[question2Answer][0]); //Question1
            jLabel7.setText(questionE[question2Answer][1]); //Question2
            jLabel8.setText(questionE[question2Answer][2]); //Question3
            jLabel9.setText(questionE[question2Answer][3]); //Question4
            jLabel10.setText(questionE[question2Answer][4]); //Question5
            
            String tmpStr = answerE[question2Answer][0];
            String[] tmp = tmpStr.split("\\|");
            
            if (tmp.length > 0) {
                jRadioButton1.setText(tmp[0]);
                jRadioButton1.setVisible(true);
            }else{
                jRadioButton1.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton2.setText(tmp[1]);
                jRadioButton2.setVisible(true);
            }else{
                jRadioButton2.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton3.setText(tmp[2]);
                jRadioButton3.setVisible(true);
            }else{
                jRadioButton3.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton4.setText(tmp[3]);
                jRadioButton4.setVisible(true);
            }else{
                jRadioButton4.setVisible(false);
            }
            
            tmpStr = answerE[question2Answer][1];
            tmp = tmpStr.split("\\|");
            
            if (tmp.length > 0) {
                jRadioButton5.setText(tmp[0]);
                jRadioButton5.setVisible(true);
            }else{
                jRadioButton5.setVisible(false);
            }
                
            if (tmp.length > 1) {
                jRadioButton6.setText(tmp[1]);
                jRadioButton6.setVisible(true);
            }else{
                jRadioButton6.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton7.setText(tmp[2]);
                jRadioButton7.setVisible(true);
            }else{
                jRadioButton7.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton8.setText(tmp[3]);
                jRadioButton8.setVisible(true);
            }else{
                jRadioButton8.setVisible(false);
            }
            
            tmpStr = answerE[question2Answer][2];
            tmp = tmpStr.split("\\|");
            
            if (tmp.length > 0) {
                jRadioButton9.setText(tmp[0]);
                jRadioButton9.setVisible(true);
            }else{
                jRadioButton9.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton10.setText(tmp[1]);
                jRadioButton10.setVisible(true);
            }else{
                jRadioButton10.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton11.setText(tmp[2]);
                jRadioButton11.setVisible(true);
            }else{
                jRadioButton11.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton12.setText(tmp[3]);
                jRadioButton12.setVisible(true);
            }else{
                jRadioButton12.setVisible(false);
            }
            
            tmpStr = answerE[question2Answer][3];
            tmp = tmpStr.split("\\|");
            
            if (tmp.length > 0) {
                jRadioButton13.setText(tmp[0]);
                jRadioButton13.setVisible(true);
            }else{
                jRadioButton13.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton14.setText(tmp[1]);
                jRadioButton14.setVisible(true);
            }else{
                jRadioButton14.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton15.setText(tmp[2]);
                jRadioButton15.setVisible(true);
            }else{
                jRadioButton15.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton16.setText(tmp[3]);
                jRadioButton16.setVisible(true);
            }else{
                jRadioButton16.setVisible(false);
            }
            
            tmpStr = answerE[question2Answer][4];
            tmp = tmpStr.split("\\|");
            
            if (tmp.length > 0) {
                jRadioButton17.setText(tmp[0]);
                jRadioButton17.setVisible(true);
            }else{
                jRadioButton17.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton18.setText(tmp[1]);
                jRadioButton18.setVisible(true);
            }else{
                jRadioButton18.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton19.setText(tmp[2]);
                jRadioButton19.setVisible(true);
            }else{
                jRadioButton19.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton20.setText(tmp[3]);
                jRadioButton20.setVisible(true);
            }else{
                jRadioButton20.setVisible(false);
            }
        }else{
            //ALL MATH
            jLabel4.setText(questionM[question2Answer][0]); //Question1
            jLabel7.setText(questionM[question2Answer][1]); //Question2
            jLabel8.setText(questionM[question2Answer][2]); //Question3
            jLabel9.setText(questionM[question2Answer][3]); //Question4
            jLabel10.setText(questionM[question2Answer][4]); //Question5
            
            String[] tmp = answerM[question2Answer][0].split("\\|");
            if (tmp.length > 0) {
                jRadioButton1.setText(tmp[0]);
                jRadioButton1.setVisible(true);
            }else{
                jRadioButton1.setVisible(false);
            }
            
            if (tmp.length > 1) {
                jRadioButton2.setText(tmp[1]);
                jRadioButton2.setVisible(true);
            }else{
                jRadioButton2.setVisible(false);
            }
            
            if (tmp.length > 2) {
                jRadioButton3.setText(tmp[2]);
                jRadioButton3.setVisible(true);
            }else{
                 jRadioButton3.setVisible(false);
            }
            
            if (tmp.length > 3) {
                jRadioButton4.setText(tmp[3]);
                jRadioButton4.setVisible(true);
            }else{
                jRadioButton4.setVisible(false);
            }
            
            tmp = answerM[question2Answer][1].split("\\|");
            if (tmp.length > 0) {
                jRadioButton5.setText(tmp[0]);
                jRadioButton5.setVisible(true);
            }else{
                jRadioButton5.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton6.setText(tmp[1]);
                jRadioButton6.setVisible(true);
            }else{
                jRadioButton6.setVisible(false);
            }
            
            if (tmp.length > 2) {
                jRadioButton7.setText(tmp[2]);
                jRadioButton7.setVisible(true);
            }else{
                jRadioButton7.setVisible(false);
            }
            
            if (tmp.length > 3) {
                jRadioButton8.setText(tmp[3]);
                jRadioButton8.setVisible(true);
            }else{
                jRadioButton8.setVisible(false);
            }
            
            tmp = answerM[question2Answer][2].split("\\|");
            if (tmp.length > 0) {
                jRadioButton9.setText(tmp[0]);
                jRadioButton9.setVisible(true);
            }else{
                jRadioButton9.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton10.setText(tmp[1]);
                jRadioButton10.setVisible(true);
            }else{
                 jRadioButton10.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton11.setText(tmp[2]);
                jRadioButton11.setVisible(true);
            }else{
                jRadioButton11.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton12.setText(tmp[3]);
                jRadioButton12.setVisible(true);
            }else{
                jRadioButton12.setVisible(false);
            }
            
            tmp = answerM[question2Answer][3].split("\\|");
            if (tmp.length > 0) {
                jRadioButton13.setText(tmp[0]);
                jRadioButton13.setVisible(true);
            }else{
                jRadioButton13.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton14.setText(tmp[1]);
                jRadioButton14.setVisible(true);
            }else{
                jRadioButton14.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton15.setText(tmp[2]);
                jRadioButton15.setVisible(true);
            }else{
                jRadioButton15.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton16.setText(tmp[3]);
                jRadioButton16.setVisible(true);
            }else{
                jRadioButton16.setVisible(false);
            }
            
            tmp = answerM[question2Answer][4].split("\\|");
            if (tmp.length > 0) {
                jRadioButton17.setText(tmp[0]);
                jRadioButton17.setVisible(true);
            }else{
                jRadioButton17.setVisible(false);
            }
            if (tmp.length > 1) {
                jRadioButton18.setText(tmp[1]);
                jRadioButton18.setVisible(true);
            }else{
                jRadioButton18.setVisible(false);
            }
            if (tmp.length > 2) {
                jRadioButton19.setText(tmp[2]);
                jRadioButton19.setVisible(true);
            }else{
                jRadioButton19.setVisible(false);
            }
            if (tmp.length > 3) {
                jRadioButton20.setText(tmp[3]);
                jRadioButton20.setVisible(true);
            }else{
                jRadioButton20.setVisible(false);
            }
        }
    }
    
    public QuizA() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ButtonGroupQ1 = new javax.swing.ButtonGroup();
        buttonGroupQ2 = new javax.swing.ButtonGroup();
        buttonGroupQ3 = new javax.swing.ButtonGroup();
        buttonGroupQ4 = new javax.swing.ButtonGroup();
        buttonGroupQ5 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jRadioButton9 = new javax.swing.JRadioButton();
        jRadioButton10 = new javax.swing.JRadioButton();
        jRadioButton11 = new javax.swing.JRadioButton();
        jRadioButton12 = new javax.swing.JRadioButton();
        jRadioButton13 = new javax.swing.JRadioButton();
        jRadioButton14 = new javax.swing.JRadioButton();
        jRadioButton15 = new javax.swing.JRadioButton();
        jRadioButton16 = new javax.swing.JRadioButton();
        jRadioButton17 = new javax.swing.JRadioButton();
        jRadioButton18 = new javax.swing.JRadioButton();
        jRadioButton19 = new javax.swing.JRadioButton();
        jRadioButton20 = new javax.swing.JRadioButton();
        jPanel4 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setName("panelStart"); // NOI18N

        jButton2.setBackground(new java.awt.Color(255, 204, 255));
        jButton2.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton2.setText("Math");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 204, 255));
        jButton1.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton1.setText("English");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 1, 18)); // NOI18N
        jLabel2.setText("Select Subject");

        jLabel1.setFont(new java.awt.Font("Cotton Cloud", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 153, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Quiz Game");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(347, 347, 347)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 1, 18)); // NOI18N
        jLabel3.setText("Select Level of Difficulty");

        jButton3.setBackground(new java.awt.Color(255, 204, 255));
        jButton3.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton3.setText("Easy");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 204, 255));
        jButton4.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton4.setText("Medium");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(255, 204, 255));
        jButton5.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton5.setText("Hard");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(288, 288, 288))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setForeground(new java.awt.Color(153, 153, 153));

        jLabel4.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Question 1: Which spelling is correct?");
        jLabel4.setName(""); // NOI18N

        jLabel7.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("Question 2: Which is correct for the following sentence? ____ went to the playground today.");
        jLabel7.setName(""); // NOI18N

        jLabel8.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Question 3: Click the correct definition for a Verb.");
        jLabel8.setName(""); // NOI18N

        jLabel9.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("Question 4: Which word in this sentence is a pronoun? She likes to eat strawberries.");
        jLabel9.setName(""); // NOI18N

        jLabel10.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Question 5: Which word here is a preposition? “House,””In,” or “Run”");
        jLabel10.setName(""); // NOI18N

        jButton6.setBackground(new java.awt.Color(204, 204, 255));
        jButton6.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Finish");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        ButtonGroupQ1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton1.setText("Butterfly");

        ButtonGroupQ1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton2.setText("Buttrefly");

        ButtonGroupQ1.add(jRadioButton3);
        jRadioButton3.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton3.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton3.setText("Butterflie");

        ButtonGroupQ1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton4.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton4.setText("Butterfligh");

        buttonGroupQ2.add(jRadioButton5);
        jRadioButton5.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton5.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton5.setText("jRadioButton5");

        buttonGroupQ2.add(jRadioButton6);
        jRadioButton6.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton6.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton6.setText("jRadioButton6");

        buttonGroupQ2.add(jRadioButton7);
        jRadioButton7.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton7.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton7.setText("jRadioButton7");

        buttonGroupQ2.add(jRadioButton8);
        jRadioButton8.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton8.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton8.setText("jRadioButton8");

        buttonGroupQ3.add(jRadioButton9);
        jRadioButton9.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton9.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton9.setText("jRadioButton9");

        buttonGroupQ3.add(jRadioButton10);
        jRadioButton10.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton10.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton10.setText("jRadioButton10");

        buttonGroupQ3.add(jRadioButton11);
        jRadioButton11.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton11.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton11.setText("jRadioButton11");

        buttonGroupQ3.add(jRadioButton12);
        jRadioButton12.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton12.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton12.setText("jRadioButton12");

        buttonGroupQ4.add(jRadioButton13);
        jRadioButton13.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton13.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton13.setText("jRadioButton13");

        buttonGroupQ4.add(jRadioButton14);
        jRadioButton14.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton14.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton14.setText("jRadioButton14");

        buttonGroupQ4.add(jRadioButton15);
        jRadioButton15.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton15.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton15.setText("jRadioButton15");

        buttonGroupQ4.add(jRadioButton16);
        jRadioButton16.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton16.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton16.setText("jRadioButton16");

        buttonGroupQ5.add(jRadioButton17);
        jRadioButton17.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton17.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton17.setText("jRadioButton17");

        buttonGroupQ5.add(jRadioButton18);
        jRadioButton18.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton18.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton18.setText("jRadioButton18");

        buttonGroupQ5.add(jRadioButton19);
        jRadioButton19.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton19.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton19.setText("jRadioButton19");

        buttonGroupQ5.add(jRadioButton20);
        jRadioButton20.setFont(new java.awt.Font("HonyaJi-Re", 0, 14)); // NOI18N
        jRadioButton20.setForeground(new java.awt.Color(153, 153, 153));
        jRadioButton20.setText("jRadioButton20");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jRadioButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 1101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jRadioButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 1071, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jRadioButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 1045, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel3Layout.createSequentialGroup()
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jRadioButton4)
                                                    .addComponent(jRadioButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jRadioButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jRadioButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jRadioButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 1027, Short.MAX_VALUE))
                                                .addGap(18, 18, 18))
                                            .addComponent(jRadioButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 1045, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jRadioButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 1045, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jRadioButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 1055, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 990, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 952, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 1073, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jRadioButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 1092, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jRadioButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 1086, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jRadioButton18, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 1086, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 1123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 1111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 1099, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1068, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(41, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton5)
                .addGap(5, 5, 5)
                .addComponent(jRadioButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton8)
                .addGap(12, 12, 12)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton12)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton16)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButton17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButton20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel4.getAccessibleContext().setAccessibleDescription("");

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N

        jTextField1.setEditable(false);
        jTextField1.setFont(new java.awt.Font("HonyaJi-Re", 1, 24)); // NOI18N
        jTextField1.setText("jTextField1");

        jLabel5.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 1, 24)); // NOI18N
        jLabel5.setText("Score");
        jLabel5.setToolTipText("");

        jButton7.setBackground(new java.awt.Color(255, 204, 255));
        jButton7.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton7.setText("Yes");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(255, 204, 255));
        jButton8.setFont(new java.awt.Font("HonyaJi-Re", 0, 18)); // NOI18N
        jButton8.setText("No");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Hiragino Maru Gothic ProN", 0, 24)); // NOI18N
        jLabel6.setText("Return to home page?");

        jLabel11.setFont(new java.awt.Font("Cotton Cloud", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 153, 255));
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Quiz Game");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(304, 304, 304)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(48, 48, 48)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel6)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        question1Answer = 0;
        
        gotoStep(1);
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        question1Answer = 1;
        
        gotoStep(1);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (question1Answer < 0) {
            infoBox("Please Choose Subject!", "Error");
            return;
        }
        
        question2Answer = 0;
        
        gotoStep(2);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if (question1Answer < 0) {
            infoBox("Please Choose Subject!", "Error");
            return;
        }
        
        question2Answer = 1;
        
        gotoStep(2);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        if (question1Answer < 0) {
            infoBox("Please Choose Subject!", "Error");
            return;
        }
        
        question2Answer = 2;
        
        gotoStep(2);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        gotoStep(0);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        if (ButtonGroupQ1.getSelection()==null || buttonGroupQ2.getSelection()==null || buttonGroupQ3.getSelection()==null || buttonGroupQ4.getSelection()==null || buttonGroupQ5.getSelection()==null )
        {
            infoBox("Please Answer All Questions!", "Error");
            return;
        }
        
        gotoStep(3);
    }//GEN-LAST:event_jButton6ActionPerformed
    
    public static void infoBox(String infoMessage, String titleBar)
    {
        JOptionPane.showMessageDialog(null, infoMessage, "" + titleBar, JOptionPane.INFORMATION_MESSAGE);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuizA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuizA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuizA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuizA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuizA Quiz = new QuizA();
                Quiz.setTitle("Quiz Game");
                Quiz.setVisible(true);
                Quiz.setLocationRelativeTo(null);
                Quiz.gotoStep(0);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup ButtonGroupQ1;
    private javax.swing.ButtonGroup buttonGroupQ2;
    private javax.swing.ButtonGroup buttonGroupQ3;
    private javax.swing.ButtonGroup buttonGroupQ4;
    private javax.swing.ButtonGroup buttonGroupQ5;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton10;
    private javax.swing.JRadioButton jRadioButton11;
    private javax.swing.JRadioButton jRadioButton12;
    private javax.swing.JRadioButton jRadioButton13;
    private javax.swing.JRadioButton jRadioButton14;
    private javax.swing.JRadioButton jRadioButton15;
    private javax.swing.JRadioButton jRadioButton16;
    private javax.swing.JRadioButton jRadioButton17;
    private javax.swing.JRadioButton jRadioButton18;
    private javax.swing.JRadioButton jRadioButton19;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton20;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JRadioButton jRadioButton9;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
